
import javax.annotation.ManagedBean;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author SAURABH
 */
@ManagedBean
public class count {
    int a=0;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }
    
}
